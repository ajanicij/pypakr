from setuptools import setup

setup(name='funniest',
      version='0.1',
      description='The funniest joke around',
      url='http://github.com/author/funniest',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=['funniest'],
      zip_safe=False)
