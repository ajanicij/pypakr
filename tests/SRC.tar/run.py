import funniest

joke =  funniest.joke()
f = open('myfile', 'w')
f.write(' ')
f.close()
