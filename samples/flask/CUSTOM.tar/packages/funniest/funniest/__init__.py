def joke():
	return 'insert a funny joke here'
