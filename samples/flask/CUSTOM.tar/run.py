import funniest

print funniest.joke()
